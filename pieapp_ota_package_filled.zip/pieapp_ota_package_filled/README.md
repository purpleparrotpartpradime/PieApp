# PieApp OTA Install Package

This folder contains everything needed for an over-the-air installation of PieApp on iPhone via GitHub Pages.

## Files

- `PieApp.ipa`  
  Placeholder for your signed PieApp IPA. Upload your signed IPA to this location:
  ```
  https://github.com/purpleparrotpartpradime/PieApp/blob/main/pieapp_ota_package/PieApp.ipa
  ```

- `manifest.plist`  
  OTA manifest pointing to the raw IPA URL:
  ```
  https://raw.githubusercontent.com/purpleparrotpartpradime/PieApp/main/pieapp_ota_package/PieApp.ipa
  ```

- `index.html`  
  Installer page using the raw manifest URL:
  ```
  itms-services://?action=download-manifest&url=https://raw.githubusercontent.com/purpleparrotpartpradime/PieApp/main/pieapp_ota_package/manifest.plist
  ```

## Usage

1. Commit all files in this folder (`pieapp_ota_package`) to your GitHub repo `PieApp` on the `main` branch.
2. Ensure GitHub Pages is enabled (set source to `main` branch `/docs` folder if desired, or serve from root if using a custom setup).
3. Access the installer on your iPhone via Safari:
   ```
   https://purpleparrotpartpradime.github.io/PieApp/pieapp_ota_package/index.html
   ```
4. Tap **Install PieApp** to begin the over-the-air installation.

**Note:** Make sure your IPA is signed with a provisioning profile including your target iPhone devices.
